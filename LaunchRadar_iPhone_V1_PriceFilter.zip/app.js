let ws=null,selected=null,account={cash:100,realized:0,wins:0,losses:0},launches=new Map(),positions=new Map(),trades=[];
const $=s=>document.querySelector(s), friction=.01;
function money(n){return '$'+Number(n||0).toFixed(2)}
function price(t){
  for(const k of ['priceSol','priceInSol','tokenPriceSol','price']){
    let n=Number(t?.[k]);
    if(n>0&&isFinite(n))return n;
  }
  // Pump.fun bonding-curve price when the feed provides virtual reserves.
  const vs=Number(t?.vSolInBondingCurve ?? t?.virtualSolReserves ?? 0);
  const vt=Number(t?.vTokensInBondingCurve ?? t?.virtualTokenReserves ?? 0);
  if(vs>0&&vt>0&&isFinite(vs)&&isFinite(vt)){
    const sol=vs>1e6?vs/1e9:vs;
    const tokens=vt>1e12?vt/1e6:vt;
    const px=sol/tokens;
    if(px>0&&isFinite(px))return px;
  }
  return null;
}
function score(t){let s=35;if(t.website||t.twitter||t.telegram)s+=10;if(t.description)s+=5;if(t.hasGithub)s+=5;let mc=Number(t.marketCapSol||0);if(mc>=5&&mc<=40)s+=10;return Math.min(100,s)}
function esc(x){return String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function age(t){let s=Math.max(0,(Date.now()-t)/1000);return s<60?s.toFixed(0)+'s':(s/60).toFixed(1)+'m'}
function sol(n){return n==null?'—':Number(n).toFixed(3)+' SOL'}
function render(){
 $('#cash').textContent=money(account.cash);$('#pl').textContent=money(account.realized);$('#wl').textContent=account.wins+' / '+account.losses;
 let eq=account.cash;for(let p of positions.values()){let px=price(p.token);eq+=px?p.qty*px:p.cost}$('#equity').textContent=money(eq);
 let arr=[...launches.values()].filter(t=>price(t)!==null).sort((a,b)=>b.first-a.first).slice(0,60);$('#count').textContent=arr.length;
 $('#launches').innerHTML=arr.map(t=>`<div class="row" onclick="selectToken('${t.mint}')"><div class="top"><span class="name">${esc(t.name||t.symbol||'NEW TOKEN')}</span><b class="${t.score>=Number($('#threshold').value||60)?'good':''}">${t.score}</b></div><div class="meta"><span>${age(t.first)}</span><span>PRICE ${price(t).toExponential(4)} SOL</span><span>MC ${sol(t.marketCapSol)}</span><span>Buys ${t.buys||0}</span><span>Sells ${t.sells||0}</span></div><div class="mint">${t.mint}</div></div>`).join('')||'<div class="empty">Waiting for launches with a live price…</div>';
 if(selected){let p=price(selected),pos=positions.get(selected.mint);$('#detail').innerHTML=`<div><b>${esc(selected.name||selected.symbol||'TOKEN')}</b> • Score ${selected.score}</div><div class="metrics"><div class="metric"><small>AGE</small><b>${age(selected.first)}</b></div><div class="metric"><small>PRICE</small><b>${p?p.toFixed(8)+' SOL':'—'}</b></div><div class="metric"><small>MARKET CAP</small><b>${sol(selected.marketCapSol)}</b></div><div class="metric"><small>BUYS / SELLS</small><b>${selected.buys||0} / ${selected.sells||0}</b></div></div><div class="mint">${selected.mint}</div><div class="actions"><button class="buy" onclick="buy()">PAPER BUY $10</button><button class="sell" onclick="sell()" ${pos?'':'disabled'}>SELL POSITION</button></div>`}
 let ps=[...positions.values()];$('#positions').innerHTML=ps.map(p=>{let px=price(p.token),pl=px?(px-p.entry)*p.qty:0;return `<div class="row"><div class="top"><b>${esc(p.token.name||p.token.symbol||'TOKEN')}</b><b class="${pl>=0?'good':'bad'}">${money(pl)}</b></div><div class="meta">Entry ${p.entry.toFixed(8)} SOL • Cost ${money(p.cost)}</div></div>`}).join('')||'<div class="empty">No open positions.</div>';
 $('#trades').innerHTML=trades.slice().reverse().map(t=>`<div class="trade"><span>${t.side} ${esc(t.symbol)}<br><small>${t.time}</small></span><b class="${t.pnl>=0?'good':'bad'}">${t.side==='SELL'?money(t.pnl):money(t.amount)}</b></div>`).join('')||'<div class="empty">No paper trades yet.</div>';
}
function selectToken(m){selected=launches.get(m);if(ws?.readyState===1)ws.send(JSON.stringify({method:'subscribeTokenTrade',keys:[m]}));render()}
window.selectToken=selectToken;
window.buy=()=>{if(!selected||positions.has(selected.mint))return;if(account.cash<10)return alert('Not enough paper cash.');let px=price(selected);if(!px)return alert('Waiting for an exact token price from a trade event.');account.cash-=10;positions.set(selected.mint,{token:selected,entry:px,qty:10/px,cost:10});trades.push({side:'BUY',symbol:selected.symbol||selected.name||'TOKEN',amount:10,pnl:0,time:new Date().toLocaleTimeString()});render()}
window.sell=()=>{if(!selected||!positions.has(selected.mint))return;let p=positions.get(selected.mint),px=price(p.token);if(!px)return alert('Waiting for current token price.');let proceeds=p.qty*px*(1-friction),pl=proceeds-p.cost;account.cash+=proceeds;account.realized+=pl;pl>=0?account.wins++:account.losses++;trades.push({side:'SELL',symbol:p.token.symbol||p.token.name||'TOKEN',amount:proceeds,pnl:pl,time:new Date().toLocaleTimeString()});positions.delete(selected.mint);render()}
$('#reset').onclick=()=>{if(confirm('Reset paper account to $100?')){account={cash:100,realized:0,wins:0,losses:0};positions.clear();trades=[];render()}}
$('#threshold').oninput=render;
function connect(){if(ws?.readyState===1)return;$('#status').textContent='CONNECTING';$('#status').className='warn';ws=new WebSocket('wss://pumpdev.io/ws');ws.onopen=()=>{ $('#status').textContent='LIVE';$('#status').className='live';ws.send(JSON.stringify({method:'subscribeNewToken'}))};ws.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch{return}if(!m.mint)return;let t=launches.get(m.mint)||{mint:m.mint,first:Date.now()};Object.assign(t,m);t.score=score(t);if(m.txType==='buy')t.buys=(t.buys||0)+1;if(m.txType==='sell')t.sells=(t.sells||0)+1;launches.set(m.mint,t);let ts=Number(m.timestamp||m.blockTime||0);if(ts){if(ts<1e12)ts*=1000;$('#latency').textContent='Latency '+Math.max(0,Date.now()-ts)+'ms'}render()};ws.onclose=()=>{ $('#status').textContent='RECONNECTING';$('#status').className='warn';setTimeout(connect,1500)};ws.onerror=()=>{$('#status').textContent='FEED ERROR';$('#status').className='warn'}}
$('#start').onclick=()=>connect();render();
